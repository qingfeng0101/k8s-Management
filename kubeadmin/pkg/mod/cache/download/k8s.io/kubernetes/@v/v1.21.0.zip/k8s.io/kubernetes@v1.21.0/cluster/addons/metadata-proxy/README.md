# Metadata proxy
==============

This metadata proxy returns a 403 for kubelet's kube-env data, but otherwise allows
pods access to the metadata server.
