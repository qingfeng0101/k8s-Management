# Kubernetes Metadata Agent

Metadata Agent is a source of metadata required by logging and monitoring agents
running on a cluster.
